import React, { useState } from 'react';
import { Settings, Plus, Pencil, Trash2 } from 'lucide-react';
import { Category } from '../types/category';
import { CategoryModal } from './CategoryModal';

interface CategoryManagerProps {
  categories: Record<string, Category>;
  onAddCategory: (category: Omit<Category, 'id'>) => void;
  onUpdateCategory: (id: string, updates: Partial<Category>) => void;
  onDeleteCategory: (id: string) => void;
}

export function CategoryManager({ 
  categories, 
  onAddCategory, 
  onUpdateCategory, 
  onDeleteCategory 
}: CategoryManagerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | undefined>();
  const [isListOpen, setIsListOpen] = useState(false);

  const handleSave = (categoryData: Omit<Category, 'id'>) => {
    if (editingCategory) {
      onUpdateCategory(editingCategory.id, categoryData);
    } else {
      onAddCategory(categoryData);
    }
    setEditingCategory(undefined);
  };

  const handleEdit = (category: Category) => {
    setEditingCategory(category);
    setIsModalOpen(true);
    setIsListOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsListOpen(!isListOpen)}
        className="p-2 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100"
        title="Manage Categories"
      >
        <Settings size={20} />
      </button>

      {isListOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
          <div className="p-2 border-b">
            <button
              onClick={() => {
                setIsModalOpen(true);
                setIsListOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
            >
              <Plus size={16} />
              Add Category
            </button>
          </div>
          
          <div className="p-2 max-h-64 overflow-y-auto">
            {Object.values(categories).map((category) => (
              <div
                key={category.id}
                className="flex items-center justify-between px-3 py-2 hover:bg-gray-50 rounded-md"
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <span className="text-sm text-gray-700">{category.name}</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleEdit(category)}
                    className="p-1 text-gray-400 hover:text-blue-500"
                  >
                    <Pencil size={14} />
                  </button>
                  <button
                    onClick={() => onDeleteCategory(category.id)}
                    className="p-1 text-gray-400 hover:text-red-500"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <CategoryModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingCategory(undefined);
        }}
        onSave={handleSave}
        editingCategory={editingCategory}
      />
    </div>
  );
}