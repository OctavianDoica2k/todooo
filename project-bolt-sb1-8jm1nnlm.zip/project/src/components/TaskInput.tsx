import React, { useState, useEffect } from 'react';
import { PlusCircle, Calendar, Flag } from 'lucide-react';
import { Task, Category } from '../types';
import { Priority } from '../types/task';
import { RecurrenceConfig } from '../types/recurrence';
import { CategorySelect } from './CategorySelect';
import { PrioritySelect } from './PrioritySelect';
import { RecurrenceSelect } from './recurrence/RecurrenceSelect';
import { RecurrenceSuggestions } from './recurrence/RecurrenceSuggestions';
import { suggestRecurrenceFromText } from '../utils/recurrencePresets';

interface TaskInputProps {
  onAddTask: (text: string, categoryId?: string, dueDate?: string, priority?: Priority, recurrence?: RecurrenceConfig) => void;
  categories: Record<string, Category>;
}

export function TaskInput({ onAddTask, categories }: TaskInputProps) {
  const [task, setTask] = useState('');
  const [categoryId, setCategoryId] = useState<string>();
  const [dueDate, setDueDate] = useState<string>();
  const [priority, setPriority] = useState<Priority>('medium');
  const [showRecurrence, setShowRecurrence] = useState(false);
  const [recurrence, setRecurrence] = useState<RecurrenceConfig>({ pattern: 'none' });
  const [showSuggestion, setShowSuggestion] = useState(false);

  useEffect(() => {
    const suggestion = suggestRecurrenceFromText(task);
    setShowSuggestion(!!suggestion);
  }, [task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (task.trim()) {
      onAddTask(
        task,
        categoryId,
        dueDate,
        priority,
        recurrence.pattern !== 'none' ? recurrence : undefined
      );
      setTask('');
      setCategoryId(undefined);
      setDueDate(undefined);
      setPriority('medium');
      setRecurrence({ pattern: 'none' });
      setShowRecurrence(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="relative">
        <input
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Add a new task..."
          className="w-full px-4 py-3 text-base rounded-lg border border-gray-200 
            focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        {showSuggestion && (
          <button
            type="button"
            onClick={() => {
              const suggestion = suggestRecurrenceFromText(task);
              if (suggestion) {
                setRecurrence(suggestion);
                setShowRecurrence(true);
                setShowSuggestion(false);
              }
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 
              px-3 py-1.5 text-sm bg-blue-50 text-blue-600 rounded-full
              hover:bg-blue-100 transition-colors"
          >
            Make recurring?
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CategorySelect
          categories={categories}
          selectedId={categoryId}
          onChange={setCategoryId}
        />
        
        <div className="flex items-center gap-2 w-full">
          <Calendar size={18} className="text-gray-400" />
          <input
            type="date"
            value={dueDate || ''}
            onChange={(e) => setDueDate(e.target.value)}
            className="w-full rounded-lg border-gray-200 py-2.5 text-base
              focus:ring-blue-500"
          />
        </div>

        <PrioritySelect value={priority} onChange={setPriority} />
        
        <button
          type="button"
          onClick={() => setShowRecurrence(!showRecurrence)}
          className="flex items-center gap-2 px-4 py-2.5 text-base text-blue-500 
            hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
        >
          {showRecurrence ? 'Hide recurrence options' : 'Set up recurring task'}
        </button>
      </div>

      {showRecurrence && (
        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
          <RecurrenceSuggestions onSelect={setRecurrence} />
          <RecurrenceSelect value={recurrence} onChange={setRecurrence} />
        </div>
      )}

      <div className="flex justify-end">
        <button
          type="submit"
          className="flex items-center gap-2 px-6 py-3 text-base bg-blue-500 
            text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          <PlusCircle size={20} />
          Add Task
        </button>
      </div>
    </form>
  );
}