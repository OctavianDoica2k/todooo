import React from 'react';

const WEEKDAYS = [
  { value: 1, label: 'M', fullLabel: 'Monday' },
  { value: 2, label: 'T', fullLabel: 'Tuesday' },
  { value: 3, label: 'W', fullLabel: 'Wednesday' },
  { value: 4, label: 'T', fullLabel: 'Thursday' },
  { value: 5, label: 'F', fullLabel: 'Friday' },
  { value: 6, label: 'S', fullLabel: 'Saturday' },
  { value: 0, label: 'S', fullLabel: 'Sunday' },
];

interface WeekdayPickerProps {
  selectedDays: number[];
  onChange: (days: number[]) => void;
}

export function WeekdayPicker({ selectedDays, onChange }: WeekdayPickerProps) {
  return (
    <div className="flex gap-1">
      {WEEKDAYS.map((day) => (
        <button
          key={day.value}
          type="button"
          title={day.fullLabel}
          onClick={() => {
            const newDays = selectedDays.includes(day.value)
              ? selectedDays.filter(d => d !== day.value)
              : [...selectedDays, day.value].sort();
            onChange(newDays);
          }}
          className={`w-8 h-8 rounded-full text-sm font-medium transition-colors
            ${selectedDays.includes(day.value)
              ? 'bg-blue-500 text-white hover:bg-blue-600'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
        >
          {day.label}
        </button>
      ))}
    </div>
  );
}