import React from 'react';
import { Calendar } from 'lucide-react';

interface RecurrenceEndPickerProps {
  endDate?: string;
  occurrences?: number;
  onEndDateChange: (date?: string) => void;
  onOccurrencesChange: (occurrences?: number) => void;
}

export function RecurrenceEndPicker({
  endDate,
  occurrences,
  onEndDateChange,
  onOccurrencesChange,
}: RecurrenceEndPickerProps) {
  const [endType, setEndType] = React.useState<'never' | 'date' | 'occurrences'>(
    endDate ? 'date' : occurrences ? 'occurrences' : 'never'
  );

  return (
    <div className="space-y-3">
      <label className="text-sm font-medium text-gray-700">End Recurrence</label>
      
      <div className="space-y-2">
        <label className="flex items-center gap-2">
          <input
            type="radio"
            checked={endType === 'never'}
            onChange={() => {
              setEndType('never');
              onEndDateChange(undefined);
              onOccurrencesChange(undefined);
            }}
            className="text-blue-500 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-600">Never</span>
        </label>

        <label className="flex items-center gap-2">
          <input
            type="radio"
            checked={endType === 'date'}
            onChange={() => {
              setEndType('date');
              onOccurrencesChange(undefined);
            }}
            className="text-blue-500 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-600">On date</span>
          {endType === 'date' && (
            <div className="flex items-center gap-2 ml-2">
              <Calendar size={16} className="text-gray-400" />
              <input
                type="date"
                value={endDate || ''}
                onChange={(e) => onEndDateChange(e.target.value || undefined)}
                className="rounded-md border-gray-200 text-sm focus:ring-blue-500"
              />
            </div>
          )}
        </label>

        <label className="flex items-center gap-2">
          <input
            type="radio"
            checked={endType === 'occurrences'}
            onChange={() => {
              setEndType('occurrences');
              onEndDateChange(undefined);
            }}
            className="text-blue-500 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-600">After</span>
          {endType === 'occurrences' && (
            <div className="flex items-center gap-2 ml-2">
              <input
                type="number"
                min="1"
                max="999"
                value={occurrences || ''}
                onChange={(e) => onOccurrencesChange(parseInt(e.target.value) || undefined)}
                className="w-20 rounded-md border-gray-200 text-sm focus:ring-blue-500"
              />
              <span className="text-sm text-gray-600">occurrences</span>
            </div>
          )}
        </label>
      </div>
    </div>
  );
}