import React, { useState } from 'react';
import { Repeat, ChevronDown, ChevronRight } from 'lucide-react';
import { RecurrencePattern, RecurrenceConfig } from '../../types/recurrence';
import { WeekdayPicker } from './WeekdayPicker';
import { MonthDayPicker } from './MonthDayPicker';
import { RecurrenceEndPicker } from './RecurrenceEndPicker';
import { RecurrenceRulePreview } from './RecurrenceRulePreview';
import { NextOccurrencesList } from './NextOccurrencesList';

interface RecurrenceSelectProps {
  value: RecurrenceConfig;
  startDate?: string;
  onChange: (config: RecurrenceConfig) => void;
}

const PATTERNS: { value: RecurrencePattern; label: string }[] = [
  { value: 'none', label: 'No Recurrence' },
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
];

export function RecurrenceSelect({ value, startDate, onChange }: RecurrenceSelectProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handlePatternChange = (pattern: RecurrencePattern) => {
    const newConfig: RecurrenceConfig = { pattern };
    if (pattern === 'weekly') newConfig.weekdays = [1];
    if (pattern === 'monthly') newConfig.dayOfMonth = 1;
    onChange(newConfig);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Repeat size={18} className="text-blue-500" />
        <select
          value={value.pattern}
          onChange={(e) => handlePatternChange(e.target.value as RecurrencePattern)}
          className="flex-1 rounded-lg border-gray-200 text-sm focus:ring-blue-500"
        >
          {PATTERNS.map(pattern => (
            <option key={pattern.value} value={pattern.value}>
              {pattern.label}
            </option>
          ))}
        </select>
      </div>

      {value.pattern !== 'none' && (
        <>
          <RecurrenceRulePreview config={value} />

          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Repeat every</span>
              <input
                type="number"
                min="1"
                max="99"
                value={value.interval || 1}
                onChange={(e) => onChange({ 
                  ...value, 
                  interval: Math.max(1, parseInt(e.target.value) || 1)
                })}
                className="w-16 rounded-md border-gray-200 text-sm focus:ring-blue-500"
              />
              <span className="text-sm text-gray-600">
                {value.pattern === 'daily' ? 'days' : 
                 value.pattern === 'weekly' ? 'weeks' : 'months'}
              </span>
            </div>

            {value.pattern === 'weekly' && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  Repeat on
                </label>
                <WeekdayPicker
                  selectedDays={value.weekdays || []}
                  onChange={(weekdays) => onChange({ ...value, weekdays })}
                />
              </div>
            )}

            {value.pattern === 'monthly' && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  Day of month
                </label>
                <MonthDayPicker
                  selectedDay={value.dayOfMonth || 1}
                  onChange={(dayOfMonth) => onChange({ ...value, dayOfMonth })}
                />
              </div>
            )}

            <RecurrenceEndPicker
              endDate={value.endDate}
              occurrences={value.occurrences}
              onEndDateChange={(endDate) => onChange({ ...value, endDate })}
              onOccurrencesChange={(occurrences) => onChange({ ...value, occurrences })}
            />

            {startDate && (
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center gap-1 text-sm text-blue-500 hover:text-blue-600"
              >
                {showAdvanced ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                {showAdvanced ? 'Hide preview' : 'Show preview'}
              </button>
            )}

            {showAdvanced && startDate && (
              <NextOccurrencesList config={value} startDate={startDate} />
            )}
          </div>
        </>
      )}
    </div>
  );
}