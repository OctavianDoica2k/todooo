import React from 'react';
import { Repeat, Calendar, CheckCircle2 } from 'lucide-react';
import { RecurrenceInfo as RecurrenceInfoType } from '../../types/recurrence';
import { formatRecurrenceRule } from '../../utils/recurrenceFormatters';
import { formatNextOccurrence } from '../../utils/recurrenceUtils';

interface RecurrenceInfoProps {
  recurrence: RecurrenceInfoType;
  compact?: boolean;
}

export function RecurrenceInfo({ recurrence, compact }: RecurrenceInfoProps) {
  const { config, nextDueDate, lastCompleted, occurrencesCompleted } = recurrence;
  const remainingOccurrences = config.occurrences 
    ? config.occurrences - (occurrencesCompleted || 0)
    : undefined;

  if (compact) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-xs">
        <Repeat size={12} />
        {formatRecurrenceRule(config)}
      </span>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-blue-600">
        <Repeat size={16} />
        <span className="font-medium">
          {formatRecurrenceRule(config)}
        </span>
      </div>

      <div className="flex items-center gap-2 text-sm text-blue-500">
        <Calendar size={14} />
        <span>Next: {formatNextOccurrence(nextDueDate)}</span>
      </div>
      
      {lastCompleted && (
        <div className="flex items-center gap-2 text-sm text-blue-500">
          <CheckCircle2 size={14} />
          <span>Last completed: {formatNextOccurrence(lastCompleted)}</span>
        </div>
      )}

      {(config.endDate || remainingOccurrences) && (
        <div className="mt-1 text-sm text-blue-500">
          {config.endDate && (
            <div>Ends on {formatNextOccurrence(config.endDate)}</div>
          )}
          {remainingOccurrences && (
            <div>{remainingOccurrences} occurrences remaining</div>
          )}
        </div>
      )}
    </div>
  );
}