import React from 'react';
import { Repeat } from 'lucide-react';
import { RecurrencePattern } from '../../types/recurrence';

const PATTERNS: { value: RecurrencePattern; label: string }[] = [
  { value: 'none', label: 'No Recurrence' },
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
];

interface RecurrencePatternPickerProps {
  value: RecurrencePattern;
  onChange: (pattern: RecurrencePattern) => void;
}

export function RecurrencePatternPicker({ value, onChange }: RecurrencePatternPickerProps) {
  return (
    <div className="flex items-center gap-2">
      <Repeat size={18} className="text-blue-500" />
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as RecurrencePattern)}
        className="flex-1 rounded-lg border-gray-200 text-sm focus:ring-blue-500"
      >
        {PATTERNS.map(pattern => (
          <option key={pattern.value} value={pattern.value}>
            {pattern.label}
          </option>
        ))}
      </select>
    </div>
  );
}