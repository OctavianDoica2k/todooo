import React from 'react';
import { RelativeMonthlyPicker } from './RelativeMonthlyPicker';
import { MonthDayPicker } from './MonthDayPicker';
import { RecurrenceConfig, RelativePosition, WeekdayName } from '../../types/recurrence';

interface MonthlyPatternPickerProps {
  config: RecurrenceConfig;
  onChange: (updates: Partial<RecurrenceConfig>) => void;
}

export function MonthlyPatternPicker({ config, onChange }: MonthlyPatternPickerProps) {
  const [type, setType] = React.useState<'day' | 'relative'>(
    config.relativeMonthly ? 'relative' : 'day'
  );

  return (
    <div className="space-y-4">
      <div className="flex gap-4">
        <label className="flex items-center gap-2">
          <input
            type="radio"
            checked={type === 'day'}
            onChange={() => {
              setType('day');
              onChange({ 
                dayOfMonth: 1,
                relativeMonthly: undefined
              });
            }}
            className="text-blue-500 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-600">Day of month</span>
        </label>
        
        <label className="flex items-center gap-2">
          <input
            type="radio"
            checked={type === 'relative'}
            onChange={() => {
              setType('relative');
              onChange({
                dayOfMonth: undefined,
                relativeMonthly: {
                  position: 'first',
                  weekday: 'monday'
                }
              });
            }}
            className="text-blue-500 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-600">Relative pattern</span>
        </label>
      </div>

      {type === 'day' && (
        <MonthDayPicker
          selectedDay={config.dayOfMonth || 1}
          onChange={(day) => onChange({ dayOfMonth: day })}
        />
      )}

      {type === 'relative' && config.relativeMonthly && (
        <RelativeMonthlyPicker
          position={config.relativeMonthly.position}
          weekday={config.relativeMonthly.weekday}
          onChange={(position, weekday) => 
            onChange({ 
              relativeMonthly: { position, weekday } 
            })
          }
        />
      )}
    </div>
  );
}