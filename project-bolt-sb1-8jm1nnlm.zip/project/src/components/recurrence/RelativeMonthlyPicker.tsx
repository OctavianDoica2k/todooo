import React from 'react';
import { RelativePosition, WeekdayName } from '../../types/recurrence';

const POSITIONS: RelativePosition[] = ['first', 'second', 'third', 'fourth', 'last'];
const WEEKDAYS: WeekdayName[] = [
  'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'
];

interface RelativeMonthlyPickerProps {
  position: RelativePosition;
  weekday: WeekdayName;
  onChange: (position: RelativePosition, weekday: WeekdayName) => void;
}

export function RelativeMonthlyPicker({ 
  position, 
  weekday, 
  onChange 
}: RelativeMonthlyPickerProps) {
  return (
    <div className="flex items-center gap-2">
      <select
        value={position}
        onChange={(e) => onChange(e.target.value as RelativePosition, weekday)}
        className="rounded-md border-gray-200 text-sm focus:ring-blue-500"
      >
        {POSITIONS.map(pos => (
          <option key={pos} value={pos}>
            {pos.charAt(0).toUpperCase() + pos.slice(1)}
          </option>
        ))}
      </select>
      
      <select
        value={weekday}
        onChange={(e) => onChange(position, e.target.value as WeekdayName)}
        className="rounded-md border-gray-200 text-sm focus:ring-blue-500"
      >
        {WEEKDAYS.map(day => (
          <option key={day} value={day}>
            {day.charAt(0).toUpperCase() + day.slice(1)}
          </option>
        ))}
      </select>
      
      <span className="text-sm text-gray-600">of each month</span>
    </div>
  );
}