import React from 'react';
import { Info } from 'lucide-react';
import { RecurrenceConfig } from '../../types/recurrence';
import { formatRecurrenceRule } from '../../utils/recurrenceFormatters';

interface RecurrenceRulePreviewProps {
  config: RecurrenceConfig;
}

export function RecurrenceRulePreview({ config }: RecurrenceRulePreviewProps) {
  if (config.pattern === 'none') return null;

  return (
    <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg">
      <Info size={16} className="text-blue-500 mt-0.5 flex-shrink-0" />
      <div className="text-sm text-blue-700">
        {formatRecurrenceRule(config)}
      </div>
    </div>
  );
}