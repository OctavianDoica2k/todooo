import React from 'react';
import { Calendar, Clock, CheckCircle2 } from 'lucide-react';
import { RecurrenceInfo } from '../../types/recurrence';
import { formatNextOccurrence, getNextOccurrenceDescription } from '../../utils/recurrenceUtils';

interface RecurrencePreviewProps {
  recurrence: RecurrenceInfo;
  compact?: boolean;
}

export function RecurrencePreview({ recurrence, compact }: RecurrencePreviewProps) {
  const { config, nextDueDate, lastCompleted, occurrencesCompleted } = recurrence;
  const remainingOccurrences = config.occurrences 
    ? config.occurrences - (occurrencesCompleted || 0)
    : undefined;

  if (compact) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-xs">
        <Clock size={12} />
        {getNextOccurrenceDescription(nextDueDate)}
        {remainingOccurrences && ` (${remainingOccurrences} left)`}
      </span>
    );
  }

  return (
    <div className="space-y-2 p-3 bg-blue-50 rounded-lg">
      <div className="flex items-center gap-2 text-blue-600">
        <Calendar size={16} />
        <span className="font-medium">
          {getNextOccurrenceDescription(nextDueDate)}
        </span>
      </div>
      
      {lastCompleted && (
        <div className="flex items-center gap-2 text-sm text-blue-500">
          <CheckCircle2 size={14} />
          <span>Last completed: {formatNextOccurrence(lastCompleted)}</span>
        </div>
      )}

      {(config.endDate || remainingOccurrences) && (
        <div className="text-sm text-blue-500">
          {config.endDate && (
            <div>Ends on {formatNextOccurrence(config.endDate)}</div>
          )}
          {remainingOccurrences && (
            <div>{remainingOccurrences} occurrences remaining</div>
          )}
        </div>
      )}
    </div>
  );
}