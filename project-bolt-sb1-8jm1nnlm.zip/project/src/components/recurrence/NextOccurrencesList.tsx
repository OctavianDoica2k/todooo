import React from 'react';
import { Calendar } from 'lucide-react';
import { RecurrenceConfig } from '../../types/recurrence';
import { getNextOccurrences } from '../../utils/recurrenceFormatters';

interface NextOccurrencesListProps {
  config: RecurrenceConfig;
  startDate: string;
}

export function NextOccurrencesList({ config, startDate }: NextOccurrencesListProps) {
  if (config.pattern === 'none') return null;

  const nextDates = getNextOccurrences(config, startDate);

  return (
    <div className="space-y-2">
      <h4 className="text-sm font-medium text-gray-700">Next Occurrences</h4>
      <div className="space-y-1">
        {nextDates.map((date, index) => (
          <div
            key={date}
            className="flex items-center gap-2 text-sm text-gray-600"
          >
            <Calendar size={14} className="text-gray-400" />
            <span>
              {new Date(date).toLocaleDateString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric'
              })}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}