import React from 'react';
import { Clock, CalendarCheck, CalendarClock } from 'lucide-react';
import { RecurrenceConfig } from '../../types/recurrence';

interface RecurrenceSuggestionProps {
  onSelect: (config: RecurrenceConfig) => void;
}

const SUGGESTIONS: Array<{
  label: string;
  icon: React.ReactNode;
  config: RecurrenceConfig;
}> = [
  {
    label: 'Every weekday',
    icon: <Clock className="w-4 h-4" />,
    config: {
      pattern: 'weekly',
      weekdays: [1, 2, 3, 4, 5]
    }
  },
  {
    label: 'Every weekend',
    icon: <CalendarCheck className="w-4 h-4" />,
    config: {
      pattern: 'weekly',
      weekdays: [0, 6]
    }
  },
  {
    label: 'Monthly on 1st',
    icon: <CalendarClock className="w-4 h-4" />,
    config: {
      pattern: 'monthly',
      dayOfMonth: 1
    }
  }
];

export function RecurrenceSuggestions({ onSelect }: RecurrenceSuggestionProps) {
  return (
    <div className="mb-4">
      <div className="text-sm font-medium text-gray-700 mb-2">Quick Patterns</div>
      <div className="flex flex-wrap gap-2">
        {SUGGESTIONS.map((suggestion, index) => (
          <button
            key={index}
            onClick={() => onSelect(suggestion.config)}
            className="inline-flex items-center gap-2 px-3 py-1.5 text-sm
              bg-white border border-gray-200 rounded-full
              hover:border-blue-500 hover:text-blue-500 transition-colors"
          >
            {suggestion.icon}
            {suggestion.label}
          </button>
        ))}
      </div>
    </div>
  );
}