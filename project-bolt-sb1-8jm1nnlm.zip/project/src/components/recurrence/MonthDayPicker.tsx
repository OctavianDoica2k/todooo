import React from 'react';

interface MonthDayPickerProps {
  selectedDay: number;
  onChange: (day: number) => void;
}

export function MonthDayPicker({ selectedDay, onChange }: MonthDayPickerProps) {
  return (
    <div className="grid grid-cols-7 gap-1">
      {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
        <button
          key={day}
          type="button"
          onClick={() => onChange(day)}
          className={`p-2 text-sm rounded-lg transition-colors
            ${selectedDay === day
              ? 'bg-blue-500 text-white'
              : 'hover:bg-gray-100'
            }`}
        >
          {day}
        </button>
      ))}
    </div>
  );
}