import React from 'react';
import { ArrowUpDown } from 'lucide-react';
import { SortOption, TaskSortProps } from '../types/sort';

const sortOptions: { value: SortOption; label: string }[] = [
  { value: 'priority', label: 'Priority' },
  { value: 'dueDate', label: 'Due Date' },
  { value: 'createdAt', label: 'Created Date' },
  { value: 'alphabetical', label: 'Alphabetical' },
];

export function TaskSort({ sort, onSortChange }: TaskSortProps) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-200 px-4 py-2">
        <ArrowUpDown size={16} className="text-gray-400 flex-shrink-0" />
        <select
          value={sort.by}
          onChange={(e) => onSortChange({ 
            ...sort, 
            by: e.target.value as SortOption 
          })}
          className="bg-transparent border-none text-sm focus:ring-0 pr-8 py-0.5 min-w-[120px]"
        >
          {sortOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <button
          onClick={() => onSortChange({ 
            ...sort, 
            direction: sort.direction === 'asc' ? 'desc' : 'asc' 
          })}
          className="flex items-center justify-center hover:bg-gray-50 rounded p-1 -mr-2"
        >
          <span className="text-gray-500 text-lg leading-none">
            {sort.direction === 'asc' ? '↑' : '↓'}
          </span>
        </button>
      </div>
    </div>
  );
}