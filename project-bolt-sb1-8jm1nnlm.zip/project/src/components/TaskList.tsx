import React, { useState } from 'react';
import { Clock, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { Task, Category } from '../types/task';
import { TaskItem } from './TaskItem';
import { getDateRangeForInterval } from '../utils/dateFilters';

interface TaskListProps {
  tasks: Task[];
  categories: Record<string, Category>;
  onToggleTask: (id: string) => void;
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void;
  onDeleteTask: (id: string) => void;
}

export function TaskList({ 
  tasks, 
  categories, 
  onToggleTask, 
  onUpdateTask, 
  onDeleteTask 
}: TaskListProps) {
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [showCompleted, setShowCompleted] = useState(true);
  const [completedInterval, setCompletedInterval] = useState<'today' | 'week' | 'month'>('week');
  
  const dateRange = getDateRangeForInterval(completedInterval);
  const pendingTasks = tasks.filter(task => !task.completed);
  const completedTasks = tasks.filter(task => 
    task.completed && 
    task.completedAt && 
    new Date(task.completedAt) >= dateRange.start &&
    new Date(task.completedAt) <= dateRange.end
  );

  return (
    <div className="space-y-6">
      {/* Pending Tasks */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="flex items-center gap-2 text-lg font-semibold text-gray-900">
            <Clock size={20} className="text-blue-500" />
            Pending Tasks
            <span className="px-2 py-0.5 text-sm bg-blue-50 text-blue-600 rounded-full">
              {pendingTasks.length}
            </span>
          </h2>
        </div>

        <div className="space-y-3">
          {pendingTasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              categories={categories}
              isEditing={task.id === editingTaskId}
              onToggle={onToggleTask}
              onEdit={() => setEditingTaskId(task.id)}
              onUpdate={onUpdateTask}
              onDelete={onDeleteTask}
              onCancelEdit={() => setEditingTaskId(null)}
            />
          ))}
        </div>
      </div>

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setShowCompleted(!showCompleted)}
              className="flex items-center gap-2 group"
            >
              <h2 className="flex items-center gap-2 text-lg font-semibold text-gray-900">
                <Check size={20} className="text-green-500" />
                Completed Tasks
                <span className="px-2 py-0.5 text-sm bg-green-50 text-green-600 rounded-full">
                  {completedTasks.length}
                </span>
              </h2>
              <span className="text-gray-400 group-hover:text-gray-600">
                {showCompleted ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </span>
            </button>

            <select
              value={completedInterval}
              onChange={(e) => setCompletedInterval(e.target.value as typeof completedInterval)}
              className="px-3 py-1.5 text-sm rounded-lg border border-gray-200 text-gray-600"
            >
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
            </select>
          </div>

          {showCompleted && (
            <div className="space-y-3">
              {completedTasks.map(task => (
                <TaskItem
                  key={task.id}
                  task={task}
                  categories={categories}
                  isEditing={task.id === editingTaskId}
                  onToggle={onToggleTask}
                  onEdit={() => setEditingTaskId(task.id)}
                  onUpdate={onUpdateTask}
                  onDelete={onDeleteTask}
                  onCancelEdit={() => setEditingTaskId(null)}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}