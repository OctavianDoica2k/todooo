import React from 'react';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';

interface CompletedTasksHeaderProps {
  count: number;
  showCompleted: boolean;
  completedInterval: 'today' | 'week' | 'month';
  onToggleShow: () => void;
  onIntervalChange: (interval: 'today' | 'week' | 'month') => void;
}

export function CompletedTasksHeader({
  count,
  showCompleted,
  completedInterval,
  onToggleShow,
  onIntervalChange,
}: CompletedTasksHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-4">
      <button
        onClick={onToggleShow}
        className="flex items-center gap-2 group"
      >
        <h2 className="flex items-center gap-2 text-lg font-semibold text-gray-900">
          <Check size={20} className="text-green-500" />
          Completed Tasks
          <span className="px-2 py-0.5 text-sm bg-green-50 text-green-600 rounded-full">
            {count}
          </span>
        </h2>
        <span className="text-gray-400 group-hover:text-gray-600">
          {showCompleted ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </span>
      </button>

      <select
        value={completedInterval}
        onChange={(e) => onIntervalChange(e.target.value as typeof completedInterval)}
        className="px-3 py-1.5 text-sm rounded-lg border border-gray-200 text-gray-600"
      >
        <option value="today">Today</option>
        <option value="week">This Week</option>
        <option value="month">This Month</option>
      </select>
    </div>
  );
}