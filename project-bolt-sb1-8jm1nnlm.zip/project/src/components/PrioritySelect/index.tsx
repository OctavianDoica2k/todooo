import React from 'react';
import { Flag } from 'lucide-react';
import { Priority } from '../../types/task';

const priorities: { value: Priority; label: string; color: string }[] = [
  { value: 'low', label: 'Low Priority', color: 'text-gray-400' },
  { value: 'medium', label: 'Medium Priority', color: 'text-yellow-500' },
  { value: 'high', label: 'High Priority', color: 'text-red-500' },
];

interface PrioritySelectProps {
  value: Priority;
  onChange: (priority: Priority) => void;
}

export function PrioritySelect({ value, onChange }: PrioritySelectProps) {
  const selectedPriority = priorities.find(p => p.value === value);

  return (
    <div className="flex items-center gap-2 w-full">
      <div className="flex-shrink-0">
        <Flag size={16} className={selectedPriority?.color} />
      </div>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as Priority)}
        className="w-full rounded-md border-gray-200 text-sm focus:border-blue-500 focus:ring-blue-500"
      >
        {priorities.map((priority) => (
          <option key={priority.value} value={priority.value}>
            {priority.label}
          </option>
        ))}
      </select>
    </div>
  );
}