import React from 'react';
import { Repeat } from 'lucide-react';
import { RecurrencePattern, RecurrenceConfig } from '../types/recurrence';

interface RecurrenceSelectProps {
  value: RecurrenceConfig;
  onChange: (config: RecurrenceConfig) => void;
}

const WEEKDAYS = [
  { value: 1, label: 'Mon' },
  { value: 2, label: 'Tue' },
  { value: 3, label: 'Wed' },
  { value: 4, label: 'Thu' },
  { value: 5, label: 'Fri' },
  { value: 6, label: 'Sat' },
  { value: 0, label: 'Sun' },
];

export function RecurrenceSelect({ value, onChange }: RecurrenceSelectProps) {
  const handlePatternChange = (pattern: RecurrencePattern) => {
    const newConfig: RecurrenceConfig = { pattern };
    if (pattern === 'weekly') newConfig.weekdays = [];
    if (pattern === 'monthly') newConfig.dayOfMonth = 1;
    onChange(newConfig);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Repeat size={16} className="text-gray-400" />
        <select
          value={value.pattern}
          onChange={(e) => handlePatternChange(e.target.value as RecurrencePattern)}
          className="block rounded-md border-gray-200 text-sm focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="none">No Recurrence</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
      </div>

      {value.pattern !== 'none' && (
        <div className="pl-6">
          <div className="flex items-center gap-2 text-sm">
            <span>Every</span>
            <input
              type="number"
              min="1"
              max="99"
              value={value.interval || 1}
              onChange={(e) => onChange({ ...value, interval: parseInt(e.target.value) || 1 })}
              className="w-16 rounded-md border-gray-200 text-sm focus:border-blue-500 focus:ring-blue-500"
            />
            <span>{value.pattern === 'daily' ? 'days' : value.pattern}</span>
          </div>

          {value.pattern === 'weekly' && (
            <div className="mt-2">
              <div className="flex flex-wrap gap-1">
                {WEEKDAYS.map((day) => (
                  <button
                    key={day.value}
                    type="button"
                    onClick={() => {
                      const weekdays = value.weekdays?.includes(day.value)
                        ? value.weekdays.filter(d => d !== day.value)
                        : [...(value.weekdays || []), day.value];
                      onChange({ ...value, weekdays });
                    }}
                    className={`px-2 py-1 text-xs rounded-full ${
                      value.weekdays?.includes(day.value)
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {value.pattern === 'monthly' && (
            <div className="mt-2">
              <select
                value={value.dayOfMonth || 1}
                onChange={(e) => onChange({ ...value, dayOfMonth: parseInt(e.target.value) })}
                className="block rounded-md border-gray-200 text-sm focus:border-blue-500 focus:ring-blue-500"
              >
                {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                  <option key={day} value={day}>
                    Day {day}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      )}
    </div>
  );
}