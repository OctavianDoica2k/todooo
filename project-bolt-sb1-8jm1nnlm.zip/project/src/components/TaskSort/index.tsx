import React from 'react';
import { ArrowUpDown } from 'lucide-react';
import { TaskSortProps } from '../../types/sort';

const sortOptions = [
  { value: 'priority', label: 'Priority' },
  { value: 'dueDate', label: 'Due Date' },
  { value: 'createdAt', label: 'Created Date' },
  { value: 'alphabetical', label: 'Alphabetical' },
];

export function TaskSort({ sort, onSortChange }: TaskSortProps) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center flex-1 bg-white rounded-lg border border-gray-200">
        <div className="flex items-center gap-3 px-3 py-2 flex-1">
          <div className="flex-shrink-0 flex items-center">
            <ArrowUpDown size={18} className="text-gray-400" />
          </div>
          <select
            value={sort.by}
            onChange={(e) => onSortChange({ ...sort, by: e.target.value as any })}
            className="w-full bg-transparent border-none text-sm focus:ring-0 pr-8"
          >
            {sortOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <button
          onClick={() => onSortChange({ 
            ...sort, 
            direction: sort.direction === 'asc' ? 'desc' : 'asc' 
          })}
          className="px-3 py-2 text-gray-400 hover:text-gray-600 border-l border-gray-200"
        >
          <span className="text-lg leading-none">
            {sort.direction === 'asc' ? '↑' : '↓'}
          </span>
        </button>
      </div>
    </div>
  );
}