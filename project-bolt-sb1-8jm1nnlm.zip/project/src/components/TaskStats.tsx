import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  BarChart3,
  ArrowUp,
  Minus,
  ArrowDown
} from 'lucide-react';
import { Task } from '../types/task';
import { calculateTaskStats } from '../utils/taskStats';

interface TaskStatsProps {
  tasks: Task[];
}

export function TaskStats({ tasks }: TaskStatsProps) {
  const stats = calculateTaskStats(tasks);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <StatCard
        icon={<BarChart3 className="text-blue-500" />}
        label="Completion Rate"
        value={`${stats.completionRate}%`}
        subtext={`${stats.completed}/${stats.total} tasks`}
      />
      
      <StatCard
        icon={<Clock className="text-yellow-500" />}
        label="Pending Tasks"
        value={stats.pending.toString()}
        subtext={`${stats.dueSoon} due soon`}
      />
      
      <StatCard
        icon={<AlertCircle className="text-red-500" />}
        label="Overdue Tasks"
        value={stats.overdue.toString()}
        subtext="Need attention"
      />
      
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-sm font-medium text-gray-500 mb-3">Priority Distribution</h3>
        <div className="space-y-2">
          <PriorityBar
            label="High"
            count={stats.byPriority.high}
            total={stats.total}
            icon={<ArrowUp size={14} className="text-red-500" />}
          />
          <PriorityBar
            label="Medium"
            count={stats.byPriority.medium}
            total={stats.total}
            icon={<Minus size={14} className="text-yellow-500" />}
          />
          <PriorityBar
            label="Low"
            count={stats.byPriority.low}
            total={stats.total}
            icon={<ArrowDown size={14} className="text-gray-400" />}
          />
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  subtext: string;
}

function StatCard({ icon, label, value, subtext }: StatCardProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-sm font-medium text-gray-500">{label}</span>
      </div>
      <div className="mt-1">
        <div className="text-2xl font-semibold text-gray-900">{value}</div>
        <div className="text-sm text-gray-500">{subtext}</div>
      </div>
    </div>
  );
}

interface PriorityBarProps {
  label: string;
  count: number;
  total: number;
  icon: React.ReactNode;
}

function PriorityBar({ label, count, total, icon }: PriorityBarProps) {
  const percentage = total ? Math.round((count / total) * 100) : 0;
  
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-1">
          {icon}
          <span className="text-gray-600">{label}</span>
        </div>
        <span className="text-gray-500">{count}</span>
      </div>
      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 rounded-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}