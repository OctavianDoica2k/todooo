import React from 'react';
import { Category } from '../../types';
import { TaskSort } from '../TaskSort';
import { TaskFilters } from '../TaskFilters';
import { TaskSort as TaskSortType } from '../../types/sort';

interface TaskControlsProps {
  categories: Record<string, Category>;
  selectedCategory: string;
  searchQuery: string;
  sort: TaskSortType;
  onCategoryChange: (categoryId: string) => void;
  onSearchChange: (query: string) => void;
  onSortChange: (sort: TaskSortType) => void;
}

export function TaskControls({
  categories,
  selectedCategory,
  searchQuery,
  sort,
  onCategoryChange,
  onSearchChange,
  onSortChange,
}: TaskControlsProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 space-y-4">
      <TaskFilters
        categories={categories}
        selectedCategory={selectedCategory}
        searchQuery={searchQuery}
        onCategoryChange={onCategoryChange}
        onSearchChange={onSearchChange}
      />
      <TaskSort sort={sort} onSortChange={onSortChange} />
    </div>
  );
}