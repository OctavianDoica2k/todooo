import React from 'react';
import { Category } from '../../types';
import { SearchInput } from './SearchInput';
import { CategoryFilter } from './CategoryFilter';

interface TaskFiltersProps {
  categories: Record<string, Category>;
  selectedCategory: string;
  searchQuery: string;
  onCategoryChange: (categoryId: string) => void;
  onSearchChange: (query: string) => void;
}

export function TaskFilters({
  categories,
  selectedCategory,
  searchQuery,
  onCategoryChange,
  onSearchChange,
}: TaskFiltersProps) {
  return (
    <div className="space-y-3">
      <SearchInput value={searchQuery} onChange={onSearchChange} />
      <CategoryFilter 
        categories={categories}
        selectedCategory={selectedCategory}
        onChange={onCategoryChange}
      />
    </div>
  );
}