import React, { useState } from 'react';
import { Check, Trash2, Tag, Flag, Pencil, ChevronDown, ChevronRight, Repeat, Calendar } from 'lucide-react';
import { Task, Category } from '../types/task';
import { getPriorityColor } from '../utils/priority';
import { TaskEdit } from './TaskEdit';
import { TaskDueStatus } from './TaskDueStatus';
import { isOverdue } from '../utils/dateStatus';
import { formatRecurrencePattern } from '../utils/recurrence';
import { formatDate } from '../utils/date';

interface TaskItemProps {
  task: Task;
  categories: Record<string, Category>;
  isEditing: boolean;
  onToggle: (id: string) => void;
  onEdit: () => void;
  onUpdate: (taskId: string, updates: Partial<Task>) => void;
  onDelete: (id: string) => void;
  onCancelEdit: () => void;
}

export function TaskItem({ 
  task, 
  categories, 
  isEditing,
  onToggle, 
  onEdit,
  onUpdate,
  onDelete,
  onCancelEdit
}: TaskItemProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  const category = task.categoryId ? categories[task.categoryId] : null;
  const priorityColor = getPriorityColor(task.priority);
  const taskIsOverdue = isOverdue(task.dueDate);

  if (isEditing) {
    return (
      <TaskEdit
        task={task}
        categories={categories}
        onSave={onUpdate}
        onCancel={onCancelEdit}
      />
    );
  }

  const hasRecurrenceInfo = task.recurrence?.config && task.recurrence.nextDueDate;
  const showRecurrenceProgress = 
    hasRecurrenceInfo && 
    task.recurrence.config.occurrences !== undefined && 
    task.recurrence.occurrencesCompleted !== undefined;

  return (
    <div className={`group rounded-xl border transition-all duration-200
      ${task.completed 
        ? 'bg-gray-50 border-gray-200' 
        : taskIsOverdue
          ? 'bg-red-50 border-red-100 hover:border-red-200'
          : 'bg-white border-gray-200 hover:border-blue-200'
      }`}
    >
      <div className="flex items-center gap-3 p-4">
        <button
          onClick={() => onToggle(task.id)}
          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
            task.completed
              ? 'border-green-500 bg-green-500'
              : 'border-gray-300 hover:border-blue-500'
          }`}
        >
          {task.completed && <Check size={12} className="text-white" />}
        </button>
        
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={task.completed ? 'text-gray-500 line-through' : 'text-gray-700'}>
              {task.text}
            </span>
            <Flag size={14} className={priorityColor} />
            <TaskDueStatus task={task} />
            {hasRecurrenceInfo && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-xs">
                <Repeat size={12} />
                {formatRecurrencePattern(task.recurrence.config)}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 ml-auto">
          {task.completed && task.completedAt && (
            <span className="text-sm text-gray-500">
              Completed {formatDate(task.completedAt)}
            </span>
          )}
          
          {category && (
            <span 
              className="flex items-center gap-1 px-2 py-1 rounded-full text-sm
                transition-colors duration-200"
              style={{ 
                backgroundColor: `${category.color}15`,
                color: category.color 
              }}
            >
              <Tag size={14} />
              {category.name}
            </span>
          )}

          <div className="flex items-center gap-1">
            {hasRecurrenceInfo && (
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="p-1.5 text-gray-400 hover:text-gray-600"
              >
                {showDetails ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              </button>
            )}
            <button
              onClick={onEdit}
              className="p-1.5 text-gray-400 hover:text-blue-500"
            >
              <Pencil size={16} />
            </button>
            <button
              onClick={() => onDelete(task.id)}
              className="p-1.5 text-gray-400 hover:text-red-500"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </div>

      {showDetails && hasRecurrenceInfo && (
        <div className="px-11 pb-4">
          <div className="space-y-2 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar size={14} className="text-blue-500" />
              <span>Next occurrence: {formatDate(task.recurrence.nextDueDate)}</span>
            </div>
            {task.recurrence.lastCompleted && (
              <div className="flex items-center gap-2">
                <Check size={14} className="text-green-500" />
                <span>Last completed: {formatDate(task.recurrence.lastCompleted)}</span>
              </div>
            )}
            {showRecurrenceProgress && (
              <div className="flex items-center gap-2">
                <Repeat size={14} className="text-blue-500" />
                <span>
                  {task.recurrence.occurrencesCompleted} of {task.recurrence.config.occurrences} occurrences completed
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}