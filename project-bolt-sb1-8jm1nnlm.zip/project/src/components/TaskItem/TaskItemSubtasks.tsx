import React from 'react';
import { SubtaskList } from '../SubtaskList';
import { Subtask } from '../../types/subtask';

interface TaskItemSubtasksProps {
  taskId: string;
  subtasks: Subtask[];
  onAdd: (taskId: string, text: string) => void;
  onToggle: (taskId: string, subtaskId: string) => void;
  onDelete: (taskId: string, subtaskId: string) => void;
}

export function TaskItemSubtasks({
  taskId,
  subtasks,
  onAdd,
  onToggle,
  onDelete
}: TaskItemSubtasksProps) {
  const subtaskProps = {
    subtasks,
    onAdd: (text: string) => onAdd(taskId, text),
    onToggle: (subtaskId: string) => onToggle(taskId, subtaskId),
    onDelete: (subtaskId: string) => onDelete(taskId, subtaskId)
  };

  return <SubtaskList {...subtaskProps} />;
}