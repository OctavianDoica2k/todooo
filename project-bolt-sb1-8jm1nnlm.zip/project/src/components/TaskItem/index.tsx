import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { Task, Category } from '../../types/task';
import { getPriorityColor } from '../../utils/priority';
import { TaskEdit } from '../TaskEdit';
import { isOverdue } from '../../utils/dateStatus';
import { TaskItemContent } from './TaskItemContent';
import { TaskItemActions } from './TaskItemActions';
import { TaskItemSubtasks } from './TaskItemSubtasks';
import { useSubtasks } from '../../features/subtasks';

interface TaskItemProps {
  task: Task;
  categories: Record<string, Category>;
  isEditing: boolean;
  onToggle: (id: string) => void;
  onEdit: () => void;
  onUpdate: (taskId: string, updates: Partial<Task>) => void;
  onDelete: (id: string) => void;
  onCancelEdit: () => void;
}

export function TaskItem({ 
  task, 
  categories, 
  isEditing,
  onToggle, 
  onEdit,
  onUpdate,
  onDelete,
  onCancelEdit
}: TaskItemProps) {
  const [showSubtasks, setShowSubtasks] = useState(false);
  const { getSubtasks, addSubtask, toggleSubtask, deleteSubtask } = useSubtasks();
  const subtasks = getSubtasks(task.id);
  
  const category = task.categoryId ? categories[task.categoryId] : null;
  const priorityColor = getPriorityColor(task.priority);
  const taskIsOverdue = isOverdue(task.dueDate);
  const hasSubtasks = subtasks.length > 0;
  const completedSubtasks = subtasks.filter(s => s.completed).length;

  if (isEditing) {
    return (
      <TaskEdit
        task={task}
        categories={categories}
        onSave={onUpdate}
        onCancel={onCancelEdit}
      />
    );
  }

  return (
    <div className={`group rounded-xl border transition-all duration-200
      ${task.completed 
        ? 'bg-gray-50 border-gray-200' 
        : taskIsOverdue
          ? 'bg-red-50 border-red-100 hover:border-red-200'
          : 'bg-white border-gray-200 hover:border-blue-200'
      }`}
    >
      <div className="flex items-center gap-3 p-4">
        <button
          onClick={() => onToggle(task.id)}
          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
            task.completed
              ? 'border-green-500 bg-green-500'
              : 'border-gray-300 hover:border-blue-500'
          }`}
        >
          {task.completed && <Check size={12} className="text-white" />}
        </button>

        <TaskItemContent
          task={task}
          priorityColor={priorityColor}
          hasSubtasks={hasSubtasks}
          completedSubtasks={completedSubtasks}
          totalSubtasks={subtasks.length}
          onClick={() => setShowSubtasks(!showSubtasks)}
        />

        <TaskItemActions
          completed={task.completed}
          completedAt={task.completedAt}
          category={category || undefined}
          showSubtasks={showSubtasks}
          onToggleSubtasks={() => setShowSubtasks(!showSubtasks)}
          onEdit={onEdit}
          onDelete={() => onDelete(task.id)}
        />
      </div>

      {showSubtasks && (
        <div className="px-11 pb-4">
          <TaskItemSubtasks
            taskId={task.id}
            subtasks={subtasks}
            onAdd={addSubtask}
            onToggle={toggleSubtask}
            onDelete={deleteSubtask}
          />
        </div>
      )}
    </div>
  );
}