import React from 'react';
import { Pencil, Trash2, Tag } from 'lucide-react';
import { Category } from '../../types/category';
import { formatDate } from '../../utils/date';

interface TaskItemActionsProps {
  completed: boolean;
  completedAt?: string;
  category?: Category;
  onEdit: () => void;
  onDelete: () => void;
}

export function TaskItemActions({
  completed,
  completedAt,
  category,
  onEdit,
  onDelete
}: TaskItemActionsProps) {
  return (
    <div className="flex items-center gap-2 ml-auto">
      {completed && completedAt && (
        <span className="text-sm text-gray-500">
          Completed {formatDate(completedAt)}
        </span>
      )}
      
      {category && (
        <span 
          className="flex items-center gap-1 px-2 py-1 rounded-full text-sm
            transition-colors duration-200"
          style={{ 
            backgroundColor: `${category.color}15`,
            color: category.color 
          }}
        >
          <Tag size={14} />
          {category.name}
        </span>
      )}

      <div className="flex items-center gap-1">
        <button
          onClick={onEdit}
          className="p-1.5 text-gray-400 hover:text-blue-500"
        >
          <Pencil size={16} />
        </button>
        <button
          onClick={onDelete}
          className="p-1.5 text-gray-400 hover:text-red-500"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
}