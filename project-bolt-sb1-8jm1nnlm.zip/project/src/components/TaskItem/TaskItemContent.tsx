import React from 'react';
import { Flag, Repeat } from 'lucide-react';
import { Task } from '../../types/task';
import { TaskDueStatus } from '../TaskDueStatus';
import { formatRecurrencePattern } from '../../utils/recurrence';

interface TaskItemContentProps {
  task: Task;
  priorityColor: string;
}

export function TaskItemContent({
  task,
  priorityColor,
}: TaskItemContentProps) {
  return (
    <div className="flex-1">
      <div className="flex items-center gap-2">
        <span className={task.completed ? 'text-gray-500 line-through' : 'text-gray-700'}>
          {task.text}
        </span>
        <Flag size={14} className={priorityColor} />
        <TaskDueStatus task={task} />
        {task.recurrence && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-xs">
            <Repeat size={12} />
            {formatRecurrencePattern(task.recurrence.config)}
          </span>
        )}
      </div>
    </div>
  );
}