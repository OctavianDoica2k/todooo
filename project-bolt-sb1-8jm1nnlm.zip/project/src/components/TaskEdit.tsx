import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Task, Category } from '../types/task';
import { CategorySelect } from './CategorySelect';
import { PrioritySelect } from './PrioritySelect';
import { RecurrenceSelect } from './RecurrenceSelect';
import { RecurrenceConfig } from '../types/recurrence';

interface TaskEditProps {
  task: Task;
  categories: Record<string, Category>;
  onSave: (taskId: string, updates: Partial<Task>) => void;
  onCancel: () => void;
}

export function TaskEdit({ task, categories, onSave, onCancel }: TaskEditProps) {
  const [text, setText] = useState(task.text);
  const [categoryId, setCategoryId] = useState(task.categoryId);
  const [dueDate, setDueDate] = useState(task.dueDate || '');
  const [priority, setPriority] = useState(task.priority);
  const [recurrence, setRecurrence] = useState<RecurrenceConfig>(
    task.recurrence?.config || { pattern: 'none' }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onSave(task.id, {
        text: text.trim(),
        categoryId,
        dueDate: dueDate || undefined,
        priority,
        ...(recurrence.pattern !== 'none' && dueDate && {
          recurrence: {
            config: recurrence,
            nextDueDate: dueDate
          }
        })
      });
    }
  };

  useEffect(() => {
    setText(task.text);
    setCategoryId(task.categoryId);
    setDueDate(task.dueDate || '');
    setPriority(task.priority);
    setRecurrence(task.recurrence?.config || { pattern: 'none' });
  }, [task]);

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-gray-50 rounded-lg">
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="flex-1 px-3 py-1.5 rounded border-gray-200 text-sm focus:ring-blue-500"
          autoFocus
        />
        <button
          type="button"
          onClick={onCancel}
          className="p-1.5 text-gray-400 hover:text-gray-600"
        >
          <X size={16} />
        </button>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CategorySelect
          categories={categories}
          selectedId={categoryId}
          onChange={setCategoryId}
        />
        
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            className="flex-1 px-2 py-1 rounded border-gray-200 text-sm focus:ring-blue-500"
          />
        </div>
        
        <PrioritySelect value={priority} onChange={setPriority} />
        
        <RecurrenceSelect value={recurrence} onChange={setRecurrence} />
      </div>

      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Save Changes
        </button>
      </div>
    </form>
  );
}