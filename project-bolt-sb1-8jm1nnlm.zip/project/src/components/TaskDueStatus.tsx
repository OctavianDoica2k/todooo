import React from 'react';
import { AlertCircle, Clock } from 'lucide-react';
import { Task } from '../types/task';
import { getTaskDateStatus } from '../utils/dateStatus';

interface TaskDueStatusProps {
  task: Task;
}

export function TaskDueStatus({ task }: TaskDueStatusProps) {
  const status = getTaskDateStatus(task);
  
  if (!status) return null;
  
  return status === 'overdue' ? (
    <span className="flex items-center gap-1 text-xs text-red-500">
      <AlertCircle size={12} />
      Overdue
    </span>
  ) : (
    <span className="flex items-center gap-1 text-xs text-yellow-500">
      <Clock size={12} />
      Due soon
    </span>
  );
}