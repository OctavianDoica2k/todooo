import React from 'react';
import { Tag } from 'lucide-react';
import { Category } from '../types';

interface CategorySelectProps {
  categories: Record<string, Category>;
  selectedId?: string;
  onChange: (categoryId: string) => void;
}

export function CategorySelect({ categories, selectedId, onChange }: CategorySelectProps) {
  return (
    <div className="flex items-center gap-2 w-full">
      <Tag size={16} className="text-gray-400 flex-shrink-0" />
      <select
        value={selectedId || ''}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border-gray-200 text-sm focus:border-blue-500 focus:ring-blue-500"
      >
        <option value="">No Category</option>
        {Object.values(categories).map((category) => (
          <option key={category.id} value={category.id}>
            {category.name}
          </option>
        ))}
      </select>
    </div>
  );
}