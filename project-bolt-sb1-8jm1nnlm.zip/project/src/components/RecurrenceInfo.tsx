import React from 'react';
import { Calendar, Repeat } from 'lucide-react';
import { RecurrenceInfo as RecurrenceInfoType } from '../types/recurrence';
import { formatNextOccurrence, formatRecurrenceDetails } from '../utils/recurrenceUtils';

interface RecurrenceInfoProps {
  recurrence?: RecurrenceInfoType;
  compact?: boolean;
}

export function RecurrenceInfo({ recurrence, compact = false }: RecurrenceInfoProps) {
  if (!recurrence) return null;

  if (compact) {
    return (
      <span className="flex items-center gap-1 text-xs text-blue-500">
        <Repeat size={12} />
        {formatRecurrenceDetails(recurrence.config)}
      </span>
    );
  }

  return (
    <div className="flex flex-col gap-1 text-sm">
      <div className="flex items-center gap-2 text-blue-500">
        <Repeat size={14} />
        <span>{formatRecurrenceDetails(recurrence.config)}</span>
      </div>
      {recurrence.nextDueDate && (
        <div className="flex items-center gap-2 text-gray-500">
          <Calendar size={14} />
          <span>Next: {formatNextOccurrence(recurrence.nextDueDate)}</span>
        </div>
      )}
      {recurrence.lastCompleted && (
        <div className="text-xs text-gray-400">
          Last completed: {formatNextOccurrence(recurrence.lastCompleted)}
        </div>
      )}
    </div>
  );
}