import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { Subtask } from '../types/subtask';

interface SubtaskListProps {
  subtasks: Subtask[];
  onAdd: (text: string) => void;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export function SubtaskList({ subtasks, onAdd, onToggle, onDelete }: SubtaskListProps) {
  const [newSubtask, setNewSubtask] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSubtask.trim()) {
      onAdd(newSubtask);
      setNewSubtask('');
    }
  };

  return (
    <div className="mt-3 space-y-2">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={newSubtask}
          onChange={(e) => setNewSubtask(e.target.value)}
          placeholder="Add subtask..."
          className="flex-1 px-3 py-1 text-sm rounded border-gray-200 focus:ring-blue-500"
        />
        <button
          type="submit"
          className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          <Plus size={16} />
        </button>
      </form>

      <div className="space-y-1.5">
        {subtasks.map((subtask) => (
          <div
            key={subtask.id}
            className="flex items-center gap-2 text-sm"
          >
            <input
              type="checkbox"
              checked={subtask.completed}
              onChange={() => onToggle(subtask.id)}
              className="rounded border-gray-300 text-blue-500 focus:ring-blue-500"
            />
            <span className={subtask.completed ? 'text-gray-500 line-through' : ''}>
              {subtask.text}
            </span>
            <button
              onClick={() => onDelete(subtask.id)}
              className="ml-auto p-1 text-gray-400 hover:text-red-500"
            >
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}