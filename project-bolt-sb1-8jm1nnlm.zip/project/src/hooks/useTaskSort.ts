import { useState, useMemo } from 'react';
import { Task, TaskSort } from '../types';
import { sortTasks } from '../utils/taskSort';

export function useTaskSort(tasks: Task[]) {
  const [sort, setSort] = useState<TaskSort>({
    by: 'createdAt',
    direction: 'desc',
  });

  const sortedTasks = useMemo(() => {
    return sortTasks(tasks, sort);
  }, [tasks, sort]);

  return { sort, setSort, sortedTasks };
}