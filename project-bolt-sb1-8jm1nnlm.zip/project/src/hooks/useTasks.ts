import { useState, useEffect } from 'react';
import { Task, Priority } from '../types/task';
import { RecurrenceConfig } from '../types/recurrence';
import { loadTasks, saveTasks } from '../utils/storage';
import { calculateNextDueDate } from '../utils/recurrence';

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>(() => loadTasks());

  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  const addTask = (
    text: string, 
    categoryId?: string, 
    dueDate?: string, 
    priority: Priority = 'medium',
    recurrenceConfig?: RecurrenceConfig
  ) => {
    const now = new Date().toISOString();
    const newTask: Task = {
      id: crypto.randomUUID(),
      text,
      completed: false,
      categoryId,
      dueDate,
      priority,
      createdAt: now,
      ...(recurrenceConfig?.pattern !== 'none' && {
        recurrence: {
          config: recurrenceConfig,
          nextDueDate: dueDate || now,
          occurrencesCompleted: 0
        }
      })
    };
    setTasks(prev => [...prev, newTask]);
  };

  const updateTask = (taskId: string, updates: Partial<Task>) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === taskId
          ? { ...task, ...updates }
          : task
      )
    );
  };

  const toggleTask = (id: string) => {
    setTasks(prev =>
      prev.map(task => {
        if (task.id !== id) return task;
        
        const completed = !task.completed;
        const now = new Date().toISOString();

        // Handle non-recurring task completion
        if (!task.recurrence) {
          return { 
            ...task, 
            completed,
            completedAt: completed ? now : undefined
          };
        }

        // Handle recurring task completion
        if (!completed) {
          return { ...task, completed };
        }

        // Create completed instance of recurring task
        const completedTask: Task = {
          ...task,
          id: crypto.randomUUID(),
          completed: true,
          completedAt: now,
          recurrence: {
            ...task.recurrence,
            lastCompleted: now
          }
        };

        // Update original recurring task
        const nextDueDate = calculateNextDueDate(
          task.recurrence.nextDueDate,
          task.recurrence.config
        );

        const updatedTask: Task = {
          ...task,
          completed: false,
          dueDate: nextDueDate,
          recurrence: {
            ...task.recurrence,
            nextDueDate,
            lastCompleted: now,
            occurrencesCompleted: (task.recurrence.occurrencesCompleted || 0) + 1
          }
        };

        return [updatedTask, completedTask];
      }).flat()
    );
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  return {
    tasks,
    addTask,
    updateTask,
    toggleTask,
    deleteTask,
  };
}