import { useState, useMemo } from 'react';
import { Task } from '../types';

export function useTaskFilters(tasks: Task[]) {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      const matchesCategory = !selectedCategory || task.categoryId === selectedCategory;
      const matchesSearch = !searchQuery || 
        task.text.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [tasks, selectedCategory, searchQuery]);

  return {
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    filteredTasks,
  };
}