import React from 'react';
import { CheckSquare, Sparkles } from 'lucide-react';
import { TaskInput } from './components/TaskInput';
import { TaskList } from './components/TaskList';
import { TaskControls } from './components/TaskControls';
import { TaskStats } from './components/TaskStats';
import { CategoryManager } from './components/CategoryManager';
import { useTasks } from './hooks/useTasks';
import { useCategories } from './hooks/useCategories';
import { useTaskFilters } from './hooks/useTaskFilters';
import { useTaskSort } from './hooks/useTaskSort';

export default function App() {
  const { tasks, addTask, updateTask, toggleTask, deleteTask } = useTasks();
  const { categories, addCategory, updateCategory, deleteCategory } = useCategories();
  const {
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    filteredTasks,
  } = useTaskFilters(tasks);
  const { sort, setSort, sortedTasks } = useTaskSort(filteredTasks);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-5xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-50 rounded-xl">
                <CheckSquare size={32} className="text-blue-500" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Task Manager</h1>
                <p className="text-sm text-gray-500 mt-0.5">Stay organized and productive</p>
              </div>
            </div>
            <CategoryManager
              categories={categories}
              onAddCategory={addCategory}
              onUpdateCategory={updateCategory}
              onDeleteCategory={deleteCategory}
            />
          </div>

          <TaskStats tasks={tasks} />
        </div>

        {/* Main Content */}
        <div className="grid gap-8 grid-cols-1 lg:grid-cols-12">
          {/* Sidebar */}
          <div className="lg:col-span-3">
            <TaskControls
              categories={categories}
              selectedCategory={selectedCategory}
              searchQuery={searchQuery}
              sort={sort}
              onCategoryChange={setSelectedCategory}
              onSearchChange={setSearchQuery}
              onSortChange={setSort}
            />
          </div>

          {/* Main Task Area */}
          <div className="lg:col-span-9 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <TaskInput onAddTask={addTask} categories={categories} />
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <TaskList
                tasks={sortedTasks}
                categories={categories}
                onToggleTask={toggleTask}
                onUpdateTask={updateTask}
                onDeleteTask={deleteTask}
              />
            </div>

            {tasks.length === 0 && (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-50 mb-4">
                  <Sparkles size={24} className="text-blue-500" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">
                  Start Fresh
                </h3>
                <p className="text-gray-500">
                  Add your first task above to get started
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}