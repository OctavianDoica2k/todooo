import { useState, useEffect } from 'react';
import { Subtask, SubtaskMap } from '../types';

const STORAGE_KEY = 'subtasks';

export function useSubtasks() {
  const [subtasks, setSubtasks] = useState<SubtaskMap>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(subtasks));
  }, [subtasks]);

  const addSubtask = (taskId: string, text: string) => {
    const newSubtask: Subtask = {
      id: crypto.randomUUID(),
      text: text.trim(),
      completed: false,
      createdAt: new Date().toISOString(),
    };

    setSubtasks(prev => ({
      ...prev,
      [taskId]: [...(prev[taskId] || []), newSubtask],
    }));
  };

  const toggleSubtask = (taskId: string, subtaskId: string) => {
    setSubtasks(prev => ({
      ...prev,
      [taskId]: prev[taskId].map(subtask =>
        subtask.id === subtaskId
          ? { ...subtask, completed: !subtask.completed }
          : subtask
      ),
    }));
  };

  const deleteSubtask = (taskId: string, subtaskId: string) => {
    setSubtasks(prev => ({
      ...prev,
      [taskId]: prev[taskId].filter(subtask => subtask.id !== subtaskId),
    }));
  };

  const getSubtasks = (taskId: string) => subtasks[taskId] || [];

  return {
    getSubtasks,
    addSubtask,
    toggleSubtask,
    deleteSubtask,
  };
}