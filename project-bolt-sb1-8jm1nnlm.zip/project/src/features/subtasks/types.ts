export interface Subtask {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
}

export interface SubtaskMap {
  [taskId: string]: Subtask[];
}