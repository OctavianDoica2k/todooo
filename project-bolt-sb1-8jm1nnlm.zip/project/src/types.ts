export interface Task {
  id: string;
  text: string;
  completed: boolean;
  categoryId?: string;
  dueDate?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  color: string;
}

export type CategoryMap = Record<string, Category>;

export type SortOption = 'dueDate' | 'createdAt' | 'alphabetical';

export interface TaskSort {
  by: SortOption;
  direction: 'asc' | 'desc';
}