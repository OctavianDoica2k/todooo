import { RecurrenceInfo } from './recurrence';

export type Priority = 'low' | 'medium' | 'high';

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  completedAt?: string;
  categoryId?: string;
  dueDate?: string;
  createdAt: string;
  priority: Priority;
  recurrence?: RecurrenceInfo;
}