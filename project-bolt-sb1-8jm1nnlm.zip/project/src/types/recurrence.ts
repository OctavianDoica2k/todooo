export type RecurrencePattern = 'daily' | 'weekly' | 'monthly' | 'none';
export type RelativePosition = 'first' | 'second' | 'third' | 'fourth' | 'last';
export type WeekdayName = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

export interface RelativeMonthlyConfig {
  position: RelativePosition;
  weekday: WeekdayName;
}

export interface RecurrenceConfig {
  pattern: RecurrencePattern;
  interval?: number;
  weekdays?: number[];
  dayOfMonth?: number;
  endDate?: string;
  occurrences?: number;
  relativeMonthly?: RelativeMonthlyConfig;
}

export interface RecurrenceInfo {
  config: RecurrenceConfig;
  nextDueDate: string;
  lastCompleted?: string;
  occurrencesCompleted?: number;
}