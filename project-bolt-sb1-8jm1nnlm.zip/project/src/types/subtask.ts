export interface Subtask {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
}

export type SubtaskMap = Record<string, Subtask[]>;