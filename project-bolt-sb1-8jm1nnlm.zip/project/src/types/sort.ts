export type SortOption = 'dueDate' | 'createdAt' | 'alphabetical' | 'priority';

export interface TaskSort {
  by: SortOption;
  direction: 'asc' | 'desc';
}

export interface TaskSortProps {
  sort: TaskSort;
  onSortChange: (sort: TaskSort) => void;
}