import { Task } from '../types/task';
import { isOverdue, isDueSoon } from './dateStatus';

export interface TaskStats {
  total: number;
  completed: number;
  pending: number;
  overdue: number;
  dueSoon: number;
  completionRate: number;
  byPriority: {
    high: number;
    medium: number;
    low: number;
  };
}

export function calculateTaskStats(tasks: Task[]): TaskStats {
  const stats = tasks.reduce((acc, task) => {
    // Count by status
    if (task.completed) acc.completed++;
    else {
      acc.pending++;
      if (isOverdue(task.dueDate)) acc.overdue++;
      if (isDueSoon(task.dueDate)) acc.dueSoon++;
    }

    // Count by priority
    acc.byPriority[task.priority]++;

    return acc;
  }, {
    completed: 0,
    pending: 0,
    overdue: 0,
    dueSoon: 0,
    byPriority: { high: 0, medium: 0, low: 0 }
  });

  return {
    ...stats,
    total: tasks.length,
    completionRate: tasks.length ? Math.round((stats.completed / tasks.length) * 100) : 0
  };
}