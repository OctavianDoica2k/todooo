import { Task, TaskSort } from '../types';
import { getPriorityWeight } from './priority';

export function sortTasks(tasks: Task[], sort: TaskSort): Task[] {
  return [...tasks].sort((a, b) => {
    let comparison = 0;

    switch (sort.by) {
      case 'priority':
        comparison = getPriorityWeight(b.priority) - getPriorityWeight(a.priority);
        break;
      case 'dueDate':
        comparison = compareDates(a.dueDate, b.dueDate);
        break;
      case 'createdAt':
        comparison = compareDates(a.createdAt, b.createdAt);
        break;
      case 'alphabetical':
        comparison = a.text.localeCompare(b.text);
        break;
    }

    return sort.direction === 'asc' ? comparison : -comparison;
  });
}

function compareDates(dateA?: string, dateB?: string): number {
  if (!dateA && !dateB) return 0;
  if (!dateA) return 1;
  if (!dateB) return -1;
  return new Date(dateA).getTime() - new Date(dateB).getTime();
}