import { RecurrenceConfig } from '../types/recurrence';

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const WEEKDAYS_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const ORDINAL_SUFFIXES = ['th', 'st', 'nd', 'rd'];

export function formatRecurrenceRule(config: RecurrenceConfig): string {
  if (config.pattern === 'none') return '';

  const parts: string[] = [];
  const interval = config.interval || 1;

  // Base pattern
  switch (config.pattern) {
    case 'daily':
      parts.push(interval === 1 ? 'Every day' : `Every ${interval} days`);
      break;
    case 'weekly':
      if (config.weekdays?.length) {
        const days = config.weekdays
          .sort((a, b) => a - b)
          .map(d => WEEKDAYS_SHORT[d])
          .join(', ');
        parts.push(
          interval === 1
            ? `Every week on ${days}`
            : `Every ${interval} weeks on ${days}`
        );
      } else {
        parts.push(interval === 1 ? 'Every week' : `Every ${interval} weeks`);
      }
      break;
    case 'monthly':
      const day = config.dayOfMonth || 1;
      const suffix = ORDINAL_SUFFIXES[day % 10] || ORDINAL_SUFFIXES[0];
      parts.push(
        interval === 1
          ? `Monthly on the ${day}${suffix}`
          : `Every ${interval} months on the ${day}${suffix}`
      );
      break;
  }

  // End condition
  if (config.endDate) {
    parts.push(`until ${formatDate(config.endDate)}`);
  } else if (config.occurrences) {
    parts.push(`for ${config.occurrences} occurrences`);
  }

  return parts.join(' ');
}

function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });
}

export function getNextOccurrences(config: RecurrenceConfig, startDate: string, count = 5): string[] {
  const dates: string[] = [];
  let currentDate = new Date(startDate);

  while (dates.length < count) {
    const nextDate = calculateNextDate(currentDate, config);
    if (!nextDate || (config.endDate && nextDate > new Date(config.endDate))) {
      break;
    }
    dates.push(nextDate.toISOString().split('T')[0]);
    currentDate = nextDate;
  }

  return dates;
}

function calculateNextDate(date: Date, config: RecurrenceConfig): Date | null {
  const next = new Date(date);
  const interval = config.interval || 1;

  switch (config.pattern) {
    case 'daily':
      next.setDate(next.getDate() + interval);
      break;
    case 'weekly':
      if (config.weekdays?.length) {
        const currentDay = next.getDay();
        const nextDay = config.weekdays.find(d => d > currentDay) ?? config.weekdays[0];
        const daysToAdd = nextDay > currentDay ? nextDay - currentDay : 7 - currentDay + nextDay;
        next.setDate(next.getDate() + daysToAdd);
      } else {
        next.setDate(next.getDate() + (7 * interval));
      }
      break;
    case 'monthly':
      next.setMonth(next.getMonth() + interval);
      if (config.dayOfMonth) {
        next.setDate(config.dayOfMonth);
      }
      break;
    default:
      return null;
  }

  return next;
}