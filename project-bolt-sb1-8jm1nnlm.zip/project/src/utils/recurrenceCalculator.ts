import { 
  RecurrenceConfig, 
  RelativePosition, 
  WeekdayName 
} from '../types/recurrence';

function getWeekdayNumber(weekday: WeekdayName): number {
  const weekdays: Record<WeekdayName, number> = {
    sunday: 0,
    monday: 1,
    tuesday: 2,
    wednesday: 3,
    thursday: 4,
    friday: 5,
    saturday: 6
  };
  return weekdays[weekday];
}

function getRelativeDate(
  year: number,
  month: number,
  position: RelativePosition,
  weekday: WeekdayName
): Date {
  const weekdayNum = getWeekdayNumber(weekday);
  const date = new Date(year, month, 1);
  const firstDay = date.getDay();
  
  let dayOffset = weekdayNum - firstDay;
  if (dayOffset < 0) dayOffset += 7;
  
  let weekOffset = 0;
  switch (position) {
    case 'first': weekOffset = 0; break;
    case 'second': weekOffset = 1; break;
    case 'third': weekOffset = 2; break;
    case 'fourth': weekOffset = 3; break;
    case 'last':
      // Start from the last possible occurrence and work backwards
      date.setMonth(month + 1, 0);
      const lastDay = date.getDay();
      dayOffset = weekdayNum - lastDay;
      if (dayOffset > 0) dayOffset -= 7;
      return new Date(year, month, date.getDate() + dayOffset);
  }
  
  date.setDate(1 + dayOffset + (weekOffset * 7));
  return date;
}

export function calculateNextOccurrence(
  fromDate: Date,
  config: RecurrenceConfig
): Date | null {
  if (config.pattern === 'none') return null;
  
  const next = new Date(fromDate);
  const interval = config.interval || 1;

  switch (config.pattern) {
    case 'daily':
      next.setDate(next.getDate() + interval);
      break;
      
    case 'weekly':
      if (config.weekdays?.length) {
        const currentDay = next.getDay();
        const nextDay = config.weekdays.find(d => d > currentDay) ?? config.weekdays[0];
        const daysToAdd = nextDay > currentDay ? nextDay - currentDay : 7 - currentDay + nextDay;
        next.setDate(next.getDate() + daysToAdd);
      } else {
        next.setDate(next.getDate() + (7 * interval));
      }
      break;
      
    case 'monthly':
      if (config.relativeMonthly) {
        const { position, weekday } = config.relativeMonthly;
        let month = next.getMonth();
        let year = next.getFullYear();
        
        // Move to next month if we're past this month's occurrence
        const thisMonth = getRelativeDate(year, month, position, weekday);
        if (thisMonth <= next) {
          month += interval;
          if (month > 11) {
            year += Math.floor(month / 12);
            month = month % 12;
          }
        }
        
        return getRelativeDate(year, month, position, weekday);
      } else if (config.dayOfMonth) {
        next.setMonth(next.getMonth() + interval);
        next.setDate(config.dayOfMonth);
      }
      break;
  }

  // Check end conditions
  if (config.endDate && next > new Date(config.endDate)) {
    return null;
  }

  return next;
}