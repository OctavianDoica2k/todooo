import { Task } from '../types/task';

export function isOverdue(dueDate?: string): boolean {
  if (!dueDate) return false;
  return new Date(dueDate) < new Date(new Date().setHours(0, 0, 0, 0));
}

export function isDueSoon(dueDate?: string): boolean {
  if (!dueDate) return false;
  const today = new Date(new Date().setHours(0, 0, 0, 0));
  const due = new Date(dueDate);
  const diffDays = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  return diffDays > 0 && diffDays <= 2;
}

export function getTaskDateStatus(task: Task) {
  if (task.completed) return null;
  if (isOverdue(task.dueDate)) return 'overdue';
  if (isDueSoon(task.dueDate)) return 'due-soon';
  return null;
}