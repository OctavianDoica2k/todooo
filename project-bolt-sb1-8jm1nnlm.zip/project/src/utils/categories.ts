import { Category } from '../types';

export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'work', name: 'Work', color: '#3B82F6' },
  { id: 'personal', name: 'Personal', color: '#10B981' },
  { id: 'shopping', name: 'Shopping', color: '#F59E0B' },
  { id: 'health', name: 'Health', color: '#EF4444' },
];

export function getCategoryColor(categoryId: string | undefined, categories: Record<string, Category>): string {
  return categoryId ? categories[categoryId]?.color : '#6B7280';
}