import { RecurrencePattern, RecurrenceConfig } from '../types/recurrence';

export function calculateNextDueDate(
  currentDueDate: string,
  config: RecurrenceConfig
): string {
  if (!config) return currentDueDate;
  
  const date = new Date(currentDueDate);
  const interval = config.interval || 1;

  switch (config.pattern) {
    case 'daily':
      date.setDate(date.getDate() + interval);
      break;
    case 'weekly':
      if (config.weekdays?.length) {
        const currentDay = date.getDay();
        const nextDay = config.weekdays.find(day => day > currentDay) ?? config.weekdays[0];
        const daysToAdd = nextDay > currentDay ? nextDay - currentDay : 7 - currentDay + nextDay;
        date.setDate(date.getDate() + daysToAdd);
      } else {
        date.setDate(date.getDate() + (7 * interval));
      }
      break;
    case 'monthly':
      if (config.dayOfMonth) {
        date.setMonth(date.getMonth() + interval);
        date.setDate(config.dayOfMonth);
      } else {
        date.setMonth(date.getMonth() + interval);
      }
      break;
    default:
      return currentDueDate;
  }

  return date.toISOString();
}

export function formatRecurrencePattern(config?: RecurrenceConfig): string {
  if (!config || config.pattern === 'none') return '';
  
  const interval = config.interval || 1;
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  switch (config.pattern) {
    case 'daily':
      return interval === 1 ? 'Daily' : `Every ${interval} days`;
    case 'weekly':
      if (config.weekdays?.length) {
        const days = config.weekdays
          .sort((a, b) => a - b)
          .map(d => weekdays[d])
          .join(', ');
        return interval === 1
          ? `Weekly on ${days}`
          : `Every ${interval} weeks on ${days}`;
      }
      return interval === 1 ? 'Weekly' : `Every ${interval} weeks`;
    case 'monthly':
      if (config.dayOfMonth) {
        return interval === 1
          ? `Monthly on day ${config.dayOfMonth}`
          : `Every ${interval} months on day ${config.dayOfMonth}`;
      }
      return interval === 1 ? 'Monthly' : `Every ${interval} months`;
    default:
      return '';
  }
}