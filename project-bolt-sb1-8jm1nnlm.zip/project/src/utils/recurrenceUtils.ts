import { RecurrenceConfig, RecurrencePattern } from '../types/recurrence';
import { formatDate } from './date';

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const WEEKDAYS_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function formatRecurrenceDetails(config: RecurrenceConfig): string {
  if (!config || config.pattern === 'none') return '';
  
  const interval = config.interval || 1;
  
  switch (config.pattern) {
    case 'daily':
      return interval === 1 ? 'Daily' : `Every ${interval} days`;
      
    case 'weekly':
      if (config.weekdays?.length) {
        const days = config.weekdays
          .sort((a, b) => a - b)
          .map(d => WEEKDAYS_SHORT[d])
          .join(', ');
        return interval === 1
          ? `Weekly on ${days}`
          : `Every ${interval} weeks on ${days}`;
      }
      return interval === 1 ? 'Weekly' : `Every ${interval} weeks`;
      
    case 'monthly':
      const dayStr = getDayOfMonthString(config.dayOfMonth || 1);
      return interval === 1
        ? `Monthly on ${dayStr}`
        : `Every ${interval} months on ${dayStr}`;
        
    default:
      return '';
  }
}

export function formatNextOccurrence(date: string): string {
  const nextDate = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const diffDays = Math.round((nextDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Tomorrow';
  if (diffDays === -1) return 'Yesterday';
  
  return formatDate(date);
}

function getDayOfMonthString(day: number): string {
  const suffix = ['th', 'st', 'nd', 'rd'];
  const v = day % 100;
  return day + (suffix[(v - 20) % 10] || suffix[v] || suffix[0]);
}

export function getNextOccurrenceDescription(date: string): string {
  const nextDate = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const diffDays = Math.round((nextDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffDays < 0) return 'Overdue';
  if (diffDays === 0) return 'Due today';
  if (diffDays === 1) return 'Due tomorrow';
  if (diffDays <= 7) return `Due this ${WEEKDAYS[nextDate.getDay()]}`;
  if (diffDays <= 14) return `Due next ${WEEKDAYS[nextDate.getDay()]}`;
  
  return `Due ${formatDate(date)}`;
}