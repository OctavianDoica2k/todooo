import { RecurrenceConfig } from '../types/recurrence';

export function suggestRecurrenceFromText(text: string): RecurrenceConfig | null {
  const lowerText = text.toLowerCase();
  
  // Daily patterns
  if (lowerText.includes('every day') || lowerText.includes('daily')) {
    return { pattern: 'daily' };
  }
  
  // Weekly patterns
  if (lowerText.includes('every week') || lowerText.includes('weekly')) {
    return { pattern: 'weekly', weekdays: [new Date().getDay()] };
  }
  
  if (lowerText.includes('every monday')) {
    return { pattern: 'weekly', weekdays: [1] };
  }
  
  // Monthly patterns
  if (lowerText.includes('every month') || lowerText.includes('monthly')) {
    return { pattern: 'monthly', dayOfMonth: new Date().getDate() };
  }
  
  // First/last day patterns
  if (lowerText.includes('first of') || lowerText.includes('1st of')) {
    return { pattern: 'monthly', dayOfMonth: 1 };
  }
  
  if (lowerText.includes('last day')) {
    return { pattern: 'monthly', dayOfMonth: 31 };
  }
  
  return null;
}